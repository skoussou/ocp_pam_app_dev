### Red Hat Process Automation Manager OpenShift Application Templates

###### Build status: [![CircleCI](https://circleci.com/gh/jboss-container-images/rhpam-7-openshift-image/tree/master.svg?style=svg)](https://circleci.com/gh/jboss-container-images/rhpam-7-openshift-image/tree/master)
